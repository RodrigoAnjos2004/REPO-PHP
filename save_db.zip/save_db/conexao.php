<?php
	$servidor = "localhost:3307";
	$usuario = "root";
	$senha = "";
	$dbname = "pizzaria_thigas";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>